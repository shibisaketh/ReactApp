import React from 'react'

// function HellowWorld(pop){
//     return(
//         <div>
//             <h1>Welcome to Home {pop.id}{pop.name}</h1>

//         </div>
//     )
// }

class HellowWorld extends React.Component 
{
    render(){
        return(
        <h1>Welcome to Home {this.props.id}{this.props.name}</h1>
        )
    }

}
export default HellowWorld