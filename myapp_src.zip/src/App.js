import logo from './logo.svg';
import './App.css';
import HellloWorld from './components/HellowWorld'
import CounterEx from './components/CounterEx';

function App() {
  return (
    <div className="App">
      {/* <HellloWorld name ="Dhruv" id ="33"/> */}
      <CounterEx/>
    </div>
  );
}

export default App;
